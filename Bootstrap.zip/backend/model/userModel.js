const { DataTypes } = require('sequelize');
const sequelize = require('../config/init');

const user = sequelize.define('user',
    {
        id: {
            primaryKey: true,
            autoIncrement: true,
            type: DataTypes.INTEGER,
        },      
        username:{
            type:DataTypes.STRING
        },
        email:{
            type:DataTypes.STRING
        },
        password:{
            type:DataTypes.STRING
        },
        Role:{
            type:DataTypes.STRING
        }
    }
);
console.log("model creates or not ",user === sequelize.models.user);
module.exports = user;