const { DataTypes, Sequelize } = require('sequelize');
const sequelize = require('../config/init');

const student = sequelize.define('student',
    {
        id: {
            primaryKey: true,
            autoIncrement: true,
            type: DataTypes.INTEGER,
        },
        name: {
            type: DataTypes.STRING
        },
        email: {
            type: DataTypes.STRING,
        },
        phone_number: {
            type: DataTypes.STRING,
        },
        city: {
            type: DataTypes.STRING,
        },
        image: {
            type: DataTypes.STRING,
        },
        // hobby: {
        //     type: Sequelize.ARRAY(Sequelize.TEXT)
        // }
    }
);
console.log("model creates or not ", student === sequelize.models.student);
module.exports = student;