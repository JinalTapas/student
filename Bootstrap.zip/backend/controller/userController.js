const user = require("../model/userModel");
require('dotenv').config();
console.log("Userrrrrrrrrr :", user);
var jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const saltRounds = 10;


const signUp = async (req, res) => {
    const salt = bcrypt.genSaltSync(saltRounds);
    const hash = bcrypt.hashSync(req.body.password, salt);
    let userData = {
        username: req.body.username,
        email: req.body.email,
        password: hash
    }
    await user.create(userData);
    return res.send({ meassage: 'User Successfully Added.', data: res.data });
};
const signIn = async (req, res) => {
    try {
        const salt = bcrypt.genSaltSync(saltRounds);
        const hash = bcrypt.hashSync(req.body.password, salt);
        const auth = await user.findOne(({ where: { email: req.body.email}, raw: true }))
        console.log("fffffffffff", bcrypt.compareSync(req.body.password, hash));

        if (auth && await bcrypt.compare(req.body.password, auth.password)) {
            const token = jwt.sign({id: auth.id}, process.env.JWT_SECRET_KEY);
            return res.send({ meassage: "Successfully Verified", token: token });
        } else {
            console.log("Auth :", auth);
            return res.status(404).send('user not found');
        }
    }
    catch (error) {
        return res.status(404).send(error);
    }

    // app.post('/user/login', async (req, res) => {
    //     try {
    //         const user = users.find(user => user.username === req.body.username);
    //         console.log(user);
    //         if (!user) {
    //             res.status(400).send('User Not Found!');
    //         }
    //         if (await bcrypt.compare(req.body.password, user.password)) {
    //             res.send('LoggedIn');
    //         } else {
    //             res.send('Not Valid User!');
    //         }
    //     } catch (e) {
    //         console.log(e.toString());
    //     }
    // })
    // else {
    //     // return res.staus(401).json({error:user not });
    // }
    // return res.json({data:auth});
    // try {
    //     const token = req.headers['x-access-token'];
    //     console.log("Header token fetch",token);
    //     const verified = jwt.verify(token, process.env.JWT_SECRET_KEY);
    //     if (verified) {
    //         return res.send("Successfully Verified");
    //     } else {
    //         return res.status(401).send(error);
    //     }
    // } catch (error) {
    //     return res.status(401).send(error);
    // }
};


// const signIn1 = async (req, res) => {
//     //email and password
//     const email = req.body.email
//     //find user exist or not
//     user.findOne({ email : req.body.email })
//         .then(user => {
//             console.log("uuuuuuuuusssssser : ",user)
//             if (user) {
//                 bcrypt.compare(req.body.password, user.password, (err, data) => {
//                     console.log("hash : ",user.password)
//                     if (err) return res.status(404).send(err)
//                     if (data) {
//                         const token = jwt.sign(req.body, process.env.JWT_SECRET_KEY);
//                         return res.status(200).json({ meassage: "Login success", token: token });
//                         // return res.status(200).json({ msg: "Login success" })
//                     }
//                     else {
//                         return res.status(401).json({ msg: "Invalid credencial" })
//                     }

//                 })
//             }
//             else {
//                 return res.status(404).send(error)
//             }

//         })

// }
module.exports = {
    signUp,
    signIn
};