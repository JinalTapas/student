// const { where } = require("sequelize");
const student = require("../model/studentModel");

//GET '/tea'
const getAllStudents = async (req, res, next) => {
    const role = req.role;
    const students = await student.findAll();
    res.json({students:students,role:role});
};

//POST '/tea'


const newStudent =async (req, res, next) => {
    let newData = {...req.body}
    if(req.file) {
        newData.image = req.file.filename
    }
    const studentr = await student.create(newData);
    res.json({message: "POST new student detail", data: studentr});
};
// const newStudent = async (req, res) => {
// let info = {
//     image: req.file.Path,
//     name: req.body.name,
//     email: req.body.email,
//     city: req.body.city,
//     phone_number: req.body.phone_number 
// }
// const students = await student.create(info)
// res.status(200).send(students)
// console.log(students)
// }
//GET '/tea/:name'
const getOneStudent =async (req, res, next) => {
       const {id }=req.params;
       const students = await student.findAll({where:{id:id}});
    res.json(students);
};
const getOneStudentforUpdate =async (req, res, next) => {
    const {id }=req.params;
    console.log("idddddd",id);
    let newData = {...req.body}
    console.log("file",req);
    if(req.file) {
        newData.image = req.file.filename
    }
    console.log(newData);
    const students = await student.update(
        newData,
          { where: { id: id } }
        );       
 res.json({message: "GET 1 Student for update",data: students});
};
//DELETE '/tea/:name'
const deleteOneStudent =async (req, res, next) => {
    const {id }=req.params;
       const students = await student.destroy({where:{id:id}});
    res.json({message: "DELETE 1 Student whos id is ",id:id});
};
//POST '/tea/:name'
// const newComment = (req, res, next) => {
//     res.json({message: "POST 1 tea comment"});
// };
//DELETE '/tea'
const deleteAllStudents = async (req, res, next) => {
    await student.destroy({truncate:true});
    res.json({message: "DELETE all students"});
};

//export controller functions
module.exports = {
    getAllStudents, 
    newStudent,
    deleteAllStudents,
    getOneStudent,
    deleteOneStudent,
    getOneStudentforUpdate,
};