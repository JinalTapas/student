var express = require('express');
var router = express.Router();
const { signUp,signIn} = require('../controller/userController');


router.post('/signUp', signUp);
router.post('/signIn', signIn);

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

module.exports = router;
