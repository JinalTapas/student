var express = require('express');
var router = express.Router();
const multer = require('multer')
const { getAllStudents, newStudent, deleteAllStudents, getOneStudent, deleteOneStudent, getOneStudentforUpdate } = require('../controller/studentController');
const authenticateUser = require('../middleware/authentication');
const authorizationUser = require('../middleware/authorization');

const storage = multer.diskStorage({
  // destination: 'public/uploads',
  destination: (req, file, cb) => {
    cb(null, 'public/uploads');
  },
  filename: function (req, file, cb) {
    const imgExt = file.mimetype.split('/');
    let lastElement = imgExt[imgExt.length - 1];
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + '.' + lastElement)
  }
})
const upload = multer({ storage: storage })

router.get('/students',authenticateUser, authorizationUser, getAllStudents);
router.post('/add-student', upload.single('image'), newStudent);
router.delete('/student', deleteAllStudents);
router.post('/update-student/:id', upload.single('image'), getOneStudentforUpdate);
router.get('/student/:id', getOneStudent);
router.delete('/student/:id', deleteOneStudent);

/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});
module.exports = router;
