const user = require("../model/userModel");

// middleware.js
var jwt = require('jsonwebtoken');
const withAuth = async function(req, res, next) {
  const token =req.headers['x-access-token'];
  console.log("Getting Token",token)
  if (!token) {
    res.status(401).send('Unauthorized: No token provided');
  }
   else {
    console.log("Enter");
    jwt.verify(token, process.env.JWT_SECRET_KEY, async function(err, decoded) {
      if (err) {
        console.log("auth error",err)
        localStorage.removeItem('token');
        res.status(401).send('Unauthorized: Invalid token');
      } else {        
        const auth = await user.findOne(({ where: { id: decoded.id}, raw: true }))
        console.log("autrgjhtg",auth)
       req.role=auth.Role
        next();
      }
    });
  }
}

module.exports = withAuth;