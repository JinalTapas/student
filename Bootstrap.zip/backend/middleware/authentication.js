// middleware.js
var jwt = require('jsonwebtoken');
const withAuth = function(req, res, next) {
  const token =req.headers['x-access-token'];
  console.log("Getting Token",token)
  if (!token) {
    res.status(401).send('Unauthorized: No token provided');
  }
   else {
    console.log("Enter");
    jwt.verify(token, process.env.JWT_SECRET_KEY, function(err, decoded) {
      if (err) {
        console.log("auth error",err)
        localStorage.removeItem('token');
        res.status(401).send('Unauthorized: Invalid token');
      } else {        
        req.id = decoded.id;
        // res.status(200).send(decoded);
        next();
      }
    });
  }
}

module.exports = withAuth;