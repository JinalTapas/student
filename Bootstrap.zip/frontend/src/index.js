import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import LandingPage from './Components/LandingPage';
import SignupPage from './Components/SignupPage';
import Login from './Components/Login';
import Welcome from './Components/Welcome';
import AddStudent from './Components/AddStudent';
import ShowStudent from './Components/ShowStudent';
const router = createBrowserRouter([
  {
    path: "/",
    element: <App/>,
    children: [
      {
        path: "/",
        element: <LandingPage />,
      },
      {
        path:'/register',
        element:<SignupPage/>,
      },
      {
        path:'/login',
        element:<Login/>,
      },
      {
        path:'/welcome',
        element:<Welcome/>,
      },
      {
        path:'/student',
        element:<AddStudent/>
      },
      {
        path:'/student/:id',
        element:<AddStudent/>,
      },
      {
        path:'/studentDetails/:id',
        element:<ShowStudent/>,
      },
    ],
  },
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(

  <React.StrictMode>    
    <RouterProvider router={router} />
  </React.StrictMode>

);

