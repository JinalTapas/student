import { Outlet } from 'react-router-dom';
import './App.css';
import LandingPage from './Components/LandingPage';
function App() {
  return (
    <>    
   {/* <LandingPage/> */}
   <Outlet/>
    </>
  );
}

export default App;
