import axios from 'axios';
import { useEffect, useState } from 'react';
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
import { Link, useParams } from 'react-router-dom';

function ShowStudent() {
    const params = useParams();
    const [studentData, setStudentData] = useState([]);
    useEffect(() => {
        if (params.id) { getStudentData(); }
    });
    async function getStudentData() {
        await axios.get(process.env.REACT_APP_BASE_URL + `student/student/${params.id}`)
            .then((res) => {
                setStudentData(res.data[0])
            })
            .catch((error) => console.log("Error while getting data : ", error));
    }
  return (
    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src={`${process.env.REACT_APP_BASE_URL}/uploads/${studentData.image}`} />
      <Card.Body>
        <Card.Title>Name : {studentData.name}</Card.Title>
        <Card.Text>
        Email : {studentData.email}<br/>
        Phone Number : {studentData.phone_number}<br/>
        City : {studentData.city}<br/>
        </Card.Text>
      </Card.Body>
      <ListGroup className="list-group-flush">
        <ListGroup.Item>{studentData.hobby && studentData.hobby.replace(/[\[\]"']+/g, '')}</ListGroup.Item>      
      </ListGroup>
      <Card.Body>
      <Link  to='/student'> <Card.Link>Add Student</Card.Link></Link>
      <Link  to='/welcome'><Card.Link >Show Student</Card.Link></Link>
      </Card.Body>
    </Card>
  );
}

export default ShowStudent;