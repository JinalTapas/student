import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function SignupPage() {
    let navigate = useNavigate();
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: ''
    });
    const formik = useFormik({
        initialValues: formData,
        validationSchema: Yup.object({
            email: Yup.string().email('Invalid email address').required('Required'),
            username: Yup.string()
                .max(15, 'Must be 15 characters or less')
                .required('Required'),
            password: Yup.string()
                .required('No password provided.')
                .min(8, 'Password is too short - should be 8 chars minimum.')
                .matches(/[a-zA-Z]/, 'Password can only contain Latin letters.')
        }),
        enableReinitialize: true,
        onSubmit: async (values) => {
            console.log("values", values);
            await axios.post(process.env.REACT_APP_BASE_URL + 'users/signUp', values)
                .then(res => {
                    console.log("User Added", res);
                    navigate('/login');

                })
                .catch(err => console.log("Fetching error while adding data", err));
        },
    });
    return (
        <Container>
            <div className="fullheight myform">
                <Form onSubmit={formik.handleSubmit} encType='multipart/form-data' className='w-50 p-4 bg-light border rounded'>
                    <Form.Group className="mb-3">
                        <Form.Label>Username</Form.Label>
                        <Form.Control type="text" placeholder="Enter username" name="username"
                            onChange={formik.handleChange}
                            value={formik.values.username} />
                        <p className='text-danger'>{formik.touched.username && formik.errors.username ? formik.errors.username
                            : null}</p>
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" placeholder="Enter email" name="email" id="email"
                            onChange={formik.handleChange}
                            value={formik.values.email} />
                        <p className='text-danger'>{formik.touched.email && formik.errors.email ? formik.errors.email : null}</p>
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" name="password" placeholder="Password" onChange={formik.handleChange}
                            value={formik.values.password} />
                        <p className='text-danger'>{formik.touched.password && formik.errors.password ? formik.errors.password : null}</p>
                    </Form.Group>
                    <Button variant="primary" type="submit">
                        Signup
                    </Button>
                </Form>
            </div>
        </Container>

    );
}

export default SignupPage;