import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Welcome() {
    let navigate = useNavigate();
    const [studentdata, setStudentData] = useState();
    const token = localStorage.getItem('token');
    const [role,setRole]=useState();
    useEffect(() => {
        async function getStudentData() {
            await axios.get(process.env.REACT_APP_BASE_URL + 'student/students', {
                headers: {
                    'x-access-token': token
                }
            })
                .then((res) => {
                    // console.log("datsdfads",res)
                    setStudentData(res.data.students)
                    (res.data.role);
                })
                .catch((error) => { console.log("Error while getting data : ", error) });

        }
        getStudentData();
        !token && navigate('/login')
    }, []);
    const handleDelete = async (id) => {
        await axios.delete(process.env.REACT_APP_BASE_URL + 'student/student/' + id)
            .then(res => console.log("Your record deleted of id", id))
            .catch(err => console.log("Error while Deleting Data : ", err));
    }

    // const [token, setToken] = useState();
    // useEffect(() => {
    //     const items = localStorage.getItem('token')|| null;

    //   }, []);
    //   console.log("items : ",items)
    return (
        <div className="fullheight myform">
            <div className='btn-wrap clearfix'    >
                <Link className='btn ' to='/student'> Add Student</Link></div>
            <div className='btn-wrap clearfix'    >
                <button onClick={(e)=>{localStorage.removeItem("token"); navigate('/login')}} className='btn '>Logout</button></div>
            <Table striped className='w-75 border rounded'>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>City</th>
                        {/* <th>Hobby</th> */}
                        <th>Image</th>
                        <th colSpan='3'>Actions</th>
                    </tr>
                </thead>
                <tbody>

                    {
                        studentdata &&
                            studentdata.map((student) => {
                                // const hobby=student.hobby.toString()
                                return <tr key={student.id}>
                                    <td>{student.id}</td>
                                    <td>{student.name}</td>
                                    <td>{student.email}</td>
                                    <td>{student.phone_number}</td>
                                    <td>{student.city}</td>
                                    {/* <td>{student.hobby.replace(/[\[\]"']+/g, '')}</td>                                     */}
                                    {/* <td>{student.hobby}</td> */}
                                    <td><div className='myimage'><img className='img-thumbnail' src={`${process.env.REACT_APP_BASE_URL}/uploads/${student.image}`} alt={student.name} /></div></td>
                                    {/* <td><button type='button' onClick={() => handleUpdate(student.id)}>Update</button></td> */}
                                   {
                                    role ==='Admin' && <><td>
                                    <Link to={{
                                        pathname: `/student/${student.id}`
                                    }} >Update</Link>
                                </td>
                                <td><button type='button' onClick={() => handleDelete(student.id)}>Delete</button></td>
                                </>}
                                    <td>
                                        <Link to={{
                                            pathname: `/studentDetails/${student.id}`
                                        }} >Show Details</Link>
                                    </td>
                                </tr>
                            })
                    }

                </tbody>
            </Table>
            {/* <AddStudent/> */}
        </div>
    );
}
