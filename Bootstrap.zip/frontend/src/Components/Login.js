import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
function LoginPage() {
    let navigate = useNavigate();
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: ''
    });
    const formik = useFormik({
        initialValues: formData,
        validationSchema: Yup.object({
            email: Yup.string().email('Invalid email address').required('Required'),
            password: Yup.string()
                .required('No password provided.')
                .min(8, 'Password is too short - should be 8 chars minimum.')
                .matches(/[a-zA-Z]/, 'Password can only contain Latin letters.')
        }),
        enableReinitialize: true,
        onSubmit: async (values) => {
            await axios.post(process.env.REACT_APP_BASE_URL + 'users/signIn', values)
                .then(res => {
                    console.log("User authorized ?", res.data.token);
                    localStorage.setItem('token', res.data.token);
                    navigate('/welcome');

                })
                .catch(err => {
                    formik.errors.email = err.response.data 
                }
                );
        },
    });
    return (
        <Container>
            <div className="fullheight myform">
                <Form onSubmit={formik.handleSubmit} className='w-50 p-4 bg-light border rounded'>
                    <Form.Group className="mb-3">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" placeholder="Enter email" name="email" id="email"
                            onChange={formik.handleChange}
                            value={formik.values.email} />
                        <p className='text-danger'>{formik.touched.email || formik.errors.email ? formik.errors.email : null}</p>
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" name="password" placeholder="Password" onChange={formik.handleChange}
                            value={formik.values.password} />
                        <p className='text-danger'>{formik.touched.password || formik.errors.password ? formik.errors.password : null}</p>
                    </Form.Group>
                    <Button variant="primary" type="submit">
                        Login
                    </Button>
                   {formik.touched.email  && <NavLink className='btn btn-primary' to='/register'>Register</NavLink>} 
                </Form>
            </div>
        </Container>

    );
}

export default LoginPage;