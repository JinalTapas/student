import React, { useEffect, useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';


export default function AddStudent() {
    // const [checkboxValues, setCheckboxValues] = useState([]);
    const navigate = useNavigate();
    const params = useParams();
    useEffect(() => {
        if (params.id) { getStudentData(); }
    }, []);
    const [file, setFile] = useState();
    const [fileStatus,setfileStatus]=useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        city: '',
        phone_number: '',
        image: '',
        // hobby: checkboxValues
    });

    async function getStudentData() {
        await axios.get(process.env.REACT_APP_BASE_URL + `student/student/${params.id}`)
            .then((res) => {
                setFormData(res.data[0]);
                console.log("Fetching data", res.data[0]);
                setFile(res.data[0].image);
                // setCheckboxValues(res.data[0].hobby);
                // setFile(`${process.env.REACT_APP_BASE_URL}/uploads/${res.data[0].image}`)
            })
            .catch((error) => console.log("Error while getting data : ", error));
    }
    // const handleCheckboxChange = (event) => {
    //     const { value, checked } = event.target;
    //     if (checked) {
    //       // If checkbox is checked, add its value to the array
    //       setCheckboxValues([...checkboxValues, value]);
    //     } else {
    //       // If checkbox is unchecked, remove its value from the array
    //       setCheckboxValues(checkboxValues.filter(item => item !== value));
    //     }
    //     formik.setFieldValue('hobby',checkboxValues);
    //   };

    const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/
    const validationSchema = Yup.object({
        name: Yup.string()
            .max(15, 'Must be 15 characters or less')
            .required('Required'),
        city: Yup.string()
            .max(12, 'Must be 12 characters or less')
            .required('Required'),
        email: Yup.string().email('Invalid email address').required('Required'),
        phone_number: Yup.string()
            .required("required")
            .matches(phoneRegExp, 'Phone number is not valid')
            .min(10, "too short")
            .max(10, "too long"),
    });
    const formik = useFormik({
        initialValues: formData,
        // validationSchema,
        enableReinitialize: true,
        onSubmit: async (values) => {
            let url = (!params.id) ? 'student/add-student' : `student/update-student/${params.id}`;
            await axios.post(process.env.REACT_APP_BASE_URL + url, values, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                }
            })
                .then(res => {
                    console.log("Value Updated", res);
                    handleReset();
                    navigate('/welcome');
                })
                .catch(err => console.log("Fetching error while updating data", err));
        },
    });
    const handleReset = () => {
        console.log("Enter in handle reset");
        formik.resetForm();
    }
    return (
        <div className='fullheight myform'>
            <form onSubmit={formik.handleSubmit} encType='multipart/form-data' className='w-50 p-3 bg-light border rounded'>
                <label>Name</label>
                <input
                    className='form-control'
                    type='text'
                    name="name"
                    onChange={formik.handleChange}
                    value={formik.values.name} /><br />
                {formik.touched.name && formik.errors.name ? (
                    <div className='error'>{formik.errors.name}</div>
                ) : null}
                <label>Phone Number</label>
                <input
                    className='form-control'
                    type='text'
                    name="phone_number"
                    onChange={formik.handleChange}
                    value={formik.values.phone_number} /><br />
                {formik.touched.phone_number && formik.errors.phone_number ? (
                    <div className='error'>{formik.errors.phone_number}</div>
                ) : null}
                <label htmlFor="city">City</label>
                <input
                    className='form-control'
                    id="city"
                    name="city"
                    type="text"
                    onChange={formik.handleChange}
                    value={formik.values.city}
                /><br />
                {formik.touched.city && formik.errors.city ? (
                    <div className='error'>{formik.errors.city}</div>
                ) : null}
                <label htmlFor="email">Email Address</label>
                <input
                    className='form-control'
                    id="email"
                    name="email"
                    type="text"
                    onChange={formik.handleChange}
                    value={formik.values.email}
                /><br />
                {formik.touched.email && formik.errors.email ? (
                    <div className='error'>{formik.errors.email}</div>
                ) : null}
                {/* {console.log("hofd",typeof formik.values.hobby,formik.values.hobby)}               
                <div role="group" aria-labelledby="checkbox-group">
                    <label>
                        <input type="checkbox" className="form-check-input" name="hobby" value="Dance" 
                       checked={formik.values.hobby.includes("Dance")}
                       onChange={formik.handleChange}
                         />
                        Dancing
                    </label>
                    <label>
                        <input type="checkbox" className="form-check-input" name="hobby" value="Sing" 
                         checked={formik.values.hobby.includes("Sing")}
                         onChange={formik.handleChange}/>
                        Singing
                    </label>
                    <label>
                        <input type="checkbox" className="form-check-input" name="hobby" value="Sport" 
                         checked={formik.values.hobby.includes("Sport")}
                         onChange={formik.handleChange}/>
                        Sports
                    </label>
                    {/* <p>Selected values: {checkboxValues}</p> 
                </div> */}
                <label className='mb-2 mt-2'>Image</label>
                <input
                    className="form-control mb-2"
                    type='file'
                    accept='image/*'
                    onChange={(e) => {
                        // console.log(e.target.files[0]);
                        formik.setFieldValue('image', e.target.files[0]);
                        setFile(URL.createObjectURL(e.target.files[0]));
                        setfileStatus(true);
                    }}
                />
                {/* {`${process.env.REACT_APP_BASE_URL}/uploads/${student.image}`} alt={student.name} */}

                {!fileStatus && <img className='myimage' src={`${process.env.REACT_APP_BASE_URL}/uploads/${file}`} alt={formik.values.name} />}
                {fileStatus && <img src={file} width="100" alt={formik.values.name} />}
                <div className='d-flex gap-1  justify-content-center'>
                    <button className='btn btn-primary mt-2' type="submit">{params.id ? "Update" : "Submit"}</button>
                    {!params.id ? <button className='mt-2 btn btn-primary' type="button" onClick={handleReset}>Clear</button> : null}
                </div>
            </form>
        </div>
    );
}
