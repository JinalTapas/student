import React from 'react';
import { NavLink } from "react-router-dom";

export default function LandingPage() {
    return (
        <div className='fullheight myform landing'>
            <NavLink className='btn btn-primary' to='/register'>
                Register
            </NavLink>
            <NavLink className='btn btn-primary' to='/login'>
                Login
            </NavLink>
        </div>
    );
}
